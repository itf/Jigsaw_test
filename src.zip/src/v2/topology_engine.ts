import paper from 'paper';
import { Point } from './types';
import { pathItemFromBoundaryData, resetPaperProject } from './paperProject';

/**
 * A Topological Graph represents the puzzle as a collection of shared edges and faces.
 * This avoids the precision issues of boolean polygon operations.
 */

export interface TopoVertex {
  id: string;
  point: paper.Point;
}

export interface TopoEdge {
  id: string;
  v1Id: string;
  v2Id: string;
  pathData: string; // The geometric path (can be a line, arc, or complex whimsy)
  faceAId: string;
  faceBId: string | null; // null if it's a boundary edge
  isMerged: boolean; // If true, this edge is "internal" to a merged group
  connectors?: { u: number; stampPathData: string; isFlipped: boolean; ownerFaceId: string }[];
}

export interface TopoFace {
  id: string;
  edgeIds: string[]; // Ordered or unordered? Ordered is better for traversal.
  seedPoint: Point;
  color: string;
}

/**
 * TopologicalEngine manages the puzzle geometry using a face-edge-vertex graph.
 * This approach is more robust than boolean operations for complex tiling
 * and ensures that shared edges are perfectly aligned.
 */
export class TopologicalEngine {
  vertices: Map<string, TopoVertex> = new Map();
  edges: Map<string, TopoEdge> = new Map();
  faces: Map<string, TopoFace> = new Map();

  constructor() {}

  /**
   * Initializes the graph from a set of Voronoi cells.
   * This version handles T-junctions by splitting edges where vertices lie on them.
   */
  initializeFromVoronoi(leafAreas: any[], width: number, height: number) {
    this.vertices.clear();
    this.edges.clear();
    this.faces.clear();

    resetPaperProject(width, height);

    // 1. Extract all segments from all paths
    const rawSegments: { p1: paper.Point; p2: paper.Point; faceId: string }[] = [];
    const allPoints: paper.Point[] = [];

    leafAreas.forEach(area => {
      const path = pathItemFromBoundaryData(area.boundary);
      const children = path instanceof paper.CompoundPath ? path.children : [path];
      
      children.forEach(child => {
        if (child instanceof paper.Path) {
          if (child.clockwise) child.reverse();

          child.segments.forEach((seg, i) => {
            const nextSeg = child.segments[(i + 1) % child.segments.length];
            const p1 = new paper.Point(
              Math.round(seg.point.x * 1000) / 1000,
              Math.round(seg.point.y * 1000) / 1000
            );
            const p2 = new paper.Point(
              Math.round(nextSeg.point.x * 1000) / 1000,
              Math.round(nextSeg.point.y * 1000) / 1000
            );

            if (p1.equals(p2)) return;

            rawSegments.push({ p1, p2, faceId: area.id });
            allPoints.push(p1);
          });
        }
      });
      
      this.faces.set(area.id, {
        id: area.id,
        edgeIds: [],
        seedPoint: area.seedPoint,
        color: area.color
      });
      path.remove();
    });

    // 2. Deduplicate vertices
    const getVertexId = (p: paper.Point) => `${Math.round(p.x * 1000) / 1000},${Math.round(p.y * 1000) / 1000}`;
    const uniquePointsMap = new Map<string, paper.Point>();
    allPoints.forEach(p => {
      const id = getVertexId(p);
      if (!uniquePointsMap.has(id)) {
        uniquePointsMap.set(id, p);
        this.vertices.set(id, { id, point: p });
      }
    });
    const uniquePoints = Array.from(uniquePointsMap.values());

    // 3. Split segments at T-junctions
    const finalEdges: { v1Id: string; v2Id: string; faceId: string }[] = [];
    const TOLERANCE = 0.01;

    rawSegments.forEach(seg => {
      const ptsOnSeg: { p: paper.Point; t: number }[] = [
        { p: seg.p1, t: 0 },
        { p: seg.p2, t: 1 }
      ];

      const vec = seg.p2.subtract(seg.p1);
      const lenSq = vec.x * vec.x + vec.y * vec.y;

      uniquePoints.forEach(v => {
        if (v.equals(seg.p1) || v.equals(seg.p2)) return;

        // Check if v lies on segment p1p2
        // Projection t = (v - p1) . (p2 - p1) / |p2 - p1|^2
        const t = v.subtract(seg.p1).dot(vec) / lenSq;
        if (t > 0.0001 && t < 0.9999) {
          const projection = seg.p1.add(vec.multiply(t));
          if (projection.getDistance(v) < TOLERANCE) {
            ptsOnSeg.push({ p: v, t });
          }
        }
      });

      // Sort points along the segment
      ptsOnSeg.sort((a, b) => a.t - b.t);

      // Create edges from consecutive points
      for (let i = 0; i < ptsOnSeg.length - 1; i++) {
        finalEdges.push({
          v1Id: getVertexId(ptsOnSeg[i].p),
          v2Id: getVertexId(ptsOnSeg[i+1].p),
          faceId: seg.faceId
        });
      }
    });

    // 4. Deduplicate edges and assign to faces
    const edgeMap: Map<string, TopoEdge> = new Map();

    finalEdges.forEach(fe => {
      const sortedIds = [fe.v1Id, fe.v2Id].sort();
      const edgeKey = sortedIds.join('|');

      if (edgeMap.has(edgeKey)) {
        const existing = edgeMap.get(edgeKey)!;
        if (fe.v1Id === existing.v1Id) {
          existing.faceAId = fe.faceId;
        } else {
          existing.faceBId = fe.faceId;
        }
      } else {
        const edge: TopoEdge = {
          id: edgeKey,
          v1Id: fe.v1Id,
          v2Id: fe.v2Id,
          pathData: `M ${this.vertices.get(fe.v1Id)!.point.x} ${this.vertices.get(fe.v1Id)!.point.y} L ${this.vertices.get(fe.v2Id)!.point.x} ${this.vertices.get(fe.v2Id)!.point.y}`,
          faceAId: fe.faceId,
          faceBId: null,
          isMerged: false
        };
        edgeMap.set(edgeKey, edge);
      }
      
      const face = this.faces.get(fe.faceId);
      if (face) face.edgeIds.push(edgeKey);
    });

    this.edges = edgeMap;
  }

  /**
   * Finds all edges shared by two faces.
   */
  findEdgesBetweenFaces(faceAId: string, faceBId: string): string[] {
    const faceA = this.faces.get(faceAId);
    if (!faceA) return [];
    
    return faceA.edgeIds.filter(eid => {
      const edge = this.edges.get(eid)!;
      return (edge.faceAId === faceAId && edge.faceBId === faceBId) ||
             (edge.faceAId === faceBId && edge.faceBId === faceAId);
    });
  }

  /**
   * Orders shared edges into a contiguous chain from one end vertex to the other
   * so arc-length parameterization matches geometric order along the interface.
   */
  private sortSharedEdgesAsChain(edgeIds: string[]): string[] {
    if (edgeIds.length <= 1) return [...edgeIds];

    const touchCount = new Map<string, number>();
    edgeIds.forEach(eid => {
      const e = this.edges.get(eid)!;
      touchCount.set(e.v1Id, (touchCount.get(e.v1Id) || 0) + 1);
      touchCount.set(e.v2Id, (touchCount.get(e.v2Id) || 0) + 1);
    });

    let startV: string | null = null;
    for (const [v, c] of touchCount) {
      if (c === 1) {
        startV = v;
        break;
      }
    }
    const e0 = this.edges.get(edgeIds[0])!;
    if (!startV) startV = e0.v1Id;

    const remaining = new Set(edgeIds);
    const sorted: string[] = [];
    let currentV = startV;

    while (remaining.size > 0) {
      let nextEid: string | null = null;
      for (const eid of remaining) {
        const e = this.edges.get(eid)!;
        if (e.v1Id === currentV || e.v2Id === currentV) {
          nextEid = eid;
          break;
        }
      }
      if (!nextEid) break;
      remaining.delete(nextEid);
      sorted.push(nextEid);
      const e = this.edges.get(nextEid)!;
      currentV = e.v1Id === currentV ? e.v2Id : e.v1Id;
    }

    return sorted.length === edgeIds.length ? sorted : [...edgeIds];
  }

  /** Geometry of the two degree-1 vertices of an open chain of edges (shared interface between two faces). */
  private getOpenChainEndpoints(sortedEdgeIds: string[]): { start: paper.Point; end: paper.Point } | null {
    if (sortedEdgeIds.length === 0) return null;
    const touchCount = new Map<string, number>();
    sortedEdgeIds.forEach(eid => {
      const e = this.edges.get(eid)!;
      touchCount.set(e.v1Id, (touchCount.get(e.v1Id) || 0) + 1);
      touchCount.set(e.v2Id, (touchCount.get(e.v2Id) || 0) + 1);
    });
    let startV: string | null = null;
    for (const [v, c] of touchCount) {
      if (c === 1) {
        startV = v;
        break;
      }
    }
    const e0 = this.edges.get(sortedEdgeIds[0])!;
    if (!startV) startV = e0.v1Id;

    let currentV = startV;
    for (const eid of sortedEdgeIds) {
      const e = this.edges.get(eid)!;
      currentV = e.v1Id === currentV ? e.v2Id : e.v1Id;
    }
    const endV = currentV;
    return {
      start: this.vertices.get(startV)!.point,
      end: this.vertices.get(endV)!.point,
    };
  }

  /**
   * Places a connector on the shared polyline at the point closest to `anchor`.
   * Use this when `anchor` comes from `getSharedPerimeter` + `getPointAtU` so the
   * topological cut matches the boolean engine and Connection-tab preview.
   *
   * `chordU` is the same [0,1] parameter passed to `getPointAtU` on the shared chord.
   * When the anchor lies on a vertex shared by two chain segments (common at u=0 or u=1),
   * projection distance ties; we break ties by preferring the segment whose arc position
   * matches `chordU * totalChainLength` so the stamp does not attach to the wrong edge.
   */
  addConnectorAtAnchor(
    faceAId: string,
    faceBId: string,
    anchor: paper.Point,
    stampPathData: string,
    isFlipped: boolean,
    ownerFaceId: string,
    chordU: number = 0.5,
    /** Endpoints of the shared chord from `getSharedPerimeter` (firstSegment → lastSegment, same order as `getPointAtU`). Used to align chord parameter with polyline chain direction. */
    chordEnd0?: paper.Point,
    chordEnd1?: paper.Point
  ) {
    let edgeIds = this.findEdgesBetweenFaces(faceAId, faceBId);
    if (edgeIds.length === 0) return;

    edgeIds = this.sortSharedEdgesAsChain(edgeIds);

    const DIST_TIE_EPS = 1e-3;
    const edgeLengths = edgeIds.map(eid => {
      const edge = this.edges.get(eid)!;
      const v1 = this.vertices.get(edge.v1Id)!.point;
      const v2 = this.vertices.get(edge.v2Id)!.point;
      return v1.getDistance(v2);
    });
    const totalLength = edgeLengths.reduce((a, b) => a + b, 0);

    const chainEnds = this.getOpenChainEndpoints(edgeIds);
    let targetArc = totalLength > 0 ? Math.max(0, Math.min(1, chordU)) * totalLength : 0;
    if (
      chainEnds &&
      totalLength > 0 &&
      chordEnd0 &&
      chordEnd1 &&
      !chordEnd0.equals(chordEnd1)
    ) {
      const dAlign = chordEnd0.getDistance(chainEnds.start) + chordEnd1.getDistance(chainEnds.end);
      const dFlip = chordEnd0.getDistance(chainEnds.end) + chordEnd1.getDistance(chainEnds.start);
      const u = Math.max(0, Math.min(1, chordU));
      targetArc = (dAlign <= dFlip ? u : 1 - u) * totalLength;
    }

    type Cand = { eid: string; t: number; dist: number; arcPos: number };
    const cands: Cand[] = [];
    let cumulative = 0;

    for (let i = 0; i < edgeIds.length; i++) {
      const eid = edgeIds[i];
      const edge = this.edges.get(eid)!;
      const v1 = this.vertices.get(edge.v1Id)!.point;
      const v2 = this.vertices.get(edge.v2Id)!.point;
      const vec = v2.subtract(v1);
      const lenSq = vec.dot(vec);
      if (lenSq < 1e-12) continue;

      const t = Math.max(0, Math.min(1, anchor.subtract(v1).dot(vec) / lenSq));
      const closest = v1.add(vec.multiply(t));
      const d = anchor.getDistance(closest);
      const len = edgeLengths[i];
      const arcPos = cumulative + t * len;
      cumulative += len;

      cands.push({ eid, t, dist: d, arcPos });
    }

    if (cands.length === 0) return;

    const minDist = Math.min(...cands.map(c => c.dist));
    const close = cands.filter(c => c.dist <= minDist + DIST_TIE_EPS);
    const pick =
      close.length === 1
        ? close[0]
        : close.reduce((best, c) =>
            Math.abs(c.arcPos - targetArc) < Math.abs(best.arcPos - targetArc) ? c : best
          );

    const edge = this.edges.get(pick.eid)!;
    if (!edge.connectors) edge.connectors = [];
    edge.connectors.push({ u: pick.t, stampPathData, isFlipped, ownerFaceId });
  }

  /**
   * Adds a connector to a shared boundary between two faces.
   * 'u' is relative to the total length of all shared edges (in chain order).
   * @param u Normalized position [0, 1] along the combined shared interface.
   */
  addConnectorToBoundary(faceAId: string, faceBId: string, u: number, stampPathData: string, isFlipped: boolean, ownerFaceId: string) {
    let edgeIds = this.findEdgesBetweenFaces(faceAId, faceBId);
    if (edgeIds.length === 0) return;

    edgeIds = this.sortSharedEdgesAsChain(edgeIds);

    let totalLength = 0;
    const edgeLengths = edgeIds.map(eid => {
      const edge = this.edges.get(eid)!;
      const v1 = this.vertices.get(edge.v1Id)!.point;
      const v2 = this.vertices.get(edge.v2Id)!.point;
      return v1.getDistance(v2);
    });
    edgeLengths.forEach(len => { totalLength += len; });

    if (totalLength === 0) return;

    const targetOffset = u * totalLength;
    let currentOffset = 0;

    for (let i = 0; i < edgeIds.length; i++) {
      const len = edgeLengths[i];
      if (targetOffset >= currentOffset && targetOffset <= currentOffset + len + 0.001) {
        const localU = (targetOffset - currentOffset) / len;
        const edge = this.edges.get(edgeIds[i])!;
        if (!edge.connectors) edge.connectors = [];
        edge.connectors.push({ u: localU, stampPathData, isFlipped, ownerFaceId });
        return;
      }
      currentOffset += len;
    }
  }

  /**
   * Merges two faces by marking their shared edges as "merged".
   */
  /**
   * Merges two adjacent faces into one.
   * The shared edge between them is marked as merged and will be ignored
   * during boundary generation.
   */
  mergeFaces(faceAId: string, faceBId: string) {
    this.edges.forEach(edge => {
      if ((edge.faceAId === faceAId && edge.faceBId === faceBId) ||
          (edge.faceAId === faceBId && edge.faceBId === faceAId)) {
        edge.isMerged = true;
      }
    });
  }

  /**
   * Returns the boundary path for a group of merged faces.
   * This is the "Traversal" step.
   */
  /**
   * Generates the final SVG boundary path for a set of merged faces.
   * It traverses the outer boundary of the group, splicing in any connectors.
   */
  getMergedBoundary(faceIds: string[]): string {
    const faceIdSet = new Set(faceIds);
    const groupEdges = new Set<string>();
    faceIdSet.forEach(fid => {
      const face = this.faces.get(fid);
      if (face) face.edgeIds.forEach(eid => groupEdges.add(eid));
    });

    // An edge is on the boundary if exactly one of its faces is in the group
    const boundaryEdges = Array.from(groupEdges).filter(eid => {
      const edge = this.edges.get(eid)!;
      const faceAIn = faceIdSet.has(edge.faceAId);
      const faceBIn = edge.faceBId ? faceIdSet.has(edge.faceBId) : false;
      return faceAIn !== faceBIn;
    });

    if (boundaryEdges.length === 0) return '';

    // Build adjacency map for vertices on the boundary
    const adj = new Map<string, string[]>();
    boundaryEdges.forEach(eid => {
      const edge = this.edges.get(eid)!;
      if (!adj.has(edge.v1Id)) adj.set(edge.v1Id, []);
      if (!adj.has(edge.v2Id)) adj.set(edge.v2Id, []);
      adj.get(edge.v1Id)!.push(eid);
      adj.get(edge.v2Id)!.push(eid);
    });

    const loops: paper.Path[] = [];
    const remainingEdges = new Set(boundaryEdges);

    while (remainingEdges.size > 0) {
      const startEdgeId = remainingEdges.values().next().value;
      const startEdge = this.edges.get(startEdgeId)!;
      remainingEdges.delete(startEdgeId);

      const faceAIn = faceIdSet.has(startEdge.faceAId);
      
      const currentLoop = new paper.Path();
      const startPath = this.getEdgePath(startEdgeId, !faceAIn);
      currentLoop.addSegments(startPath.segments.map(s => s.clone()));
      
      let currentVId = faceAIn ? startEdge.v2Id : startEdge.v1Id;
      let startVId = faceAIn ? startEdge.v1Id : startEdge.v2Id;
      startPath.remove();

      let foundNext = true;
      while (foundNext && currentVId !== startVId) {
        foundNext = false;
        const possibleEdges = adj.get(currentVId) || [];
        for (const eid of possibleEdges) {
          if (remainingEdges.has(eid)) {
            const edge = this.edges.get(eid)!;
            const faceAIn = faceIdSet.has(edge.faceAId);
            
            let nextPath: paper.Path | null = null;
            if (edge.v1Id === currentVId && faceAIn) {
              nextPath = this.getEdgePath(eid, false);
              currentVId = edge.v2Id;
            } else if (edge.v2Id === currentVId && !faceAIn) {
              nextPath = this.getEdgePath(eid, true);
              currentVId = edge.v1Id;
            }

            if (nextPath) {
              // Add all segments except the first one (which is redundant with the last one of currentLoop)
              // But we need to make sure the last segment of currentLoop gets the handleIn from the first segment of nextPath?
              // Actually, in paper.js, if we use addSegments, it just adds them.
              // If the points are identical, we should probably merge them or just skip the first point.
              // To preserve handles correctly, we should update the last segment of currentLoop with the handleOut of the first segment of nextPath.
              const firstSeg = nextPath.segments[0];
              const lastSeg = currentLoop.lastSegment;
              lastSeg.handleOut = firstSeg.handleOut.clone();
              
              currentLoop.addSegments(nextPath.segments.slice(1).map(s => s.clone()));
              nextPath.remove();
              remainingEdges.delete(eid);
              foundNext = true;
              break;
            }
          }
        }
      }
      
      // Close the loop correctly: the last segment's handleOut should go to the first segment's handleIn
      if (currentLoop.segments.length > 2) {
        const firstSeg = currentLoop.firstSegment;
        const lastSeg = currentLoop.lastSegment;
        if (firstSeg.point.getDistance(lastSeg.point) < 0.001) {
          firstSeg.handleIn = lastSeg.handleIn.clone();
          lastSeg.remove();
        }
        currentLoop.closePath();
        loops.push(currentLoop);
      } else {
        currentLoop.remove();
      }
    }

    if (loops.length === 0) return '';
    
    // Combine all loops into a single path data string
    let finalPathData = "";
    loops.forEach(l => {
      finalPathData += (finalPathData ? " " : "") + l.pathData;
      l.remove();
    });
    
    return finalPathData;
  }

  /**
   * Gets the path for an edge, optionally reversed, and with connectors applied.
   */
  private getEdgePath(edgeId: string, reversed: boolean): paper.Path {
    const edge = this.edges.get(edgeId)!;
    const v1 = this.vertices.get(edge.v1Id)!.point;
    const v2 = this.vertices.get(edge.v2Id)!.point;
    
    if (!edge.connectors || edge.connectors.length === 0) {
      const path = new paper.Path();
      path.add(v1);
      path.add(v2);
      if (reversed) path.reverse();
      return path;
    }

    // Sort connectors by position along the edge
    const sorted = [...edge.connectors].sort((a, b) => a.u - b.u);
    
    // We'll build a new path by splicing connectors into the original edge
    const newPath = new paper.Path();
    newPath.add(v1);
    
    const vec = v2.subtract(v1);
    const tangent = vec.normalize();
    const angle = tangent.angle;

    sorted.forEach(c => {
      const pos = v1.add(vec.multiply(c.u));
      const stamp = new paper.Path(c.stampPathData);
      
      // Convention: raw stamp points RIGHT (0 degrees)
      // side = 1 means point into A (-90 relative to tangent)
      // side = -1 means point into B (+90 relative to tangent)
      // If owner is Face A, it should point into Face B, so side = -1.
      // If owner is Face B, it should point into Face A, so side = 1.
      let side = (c.ownerFaceId === edge.faceAId) ? -1 : 1;
      
      const rotation = angle - 90 * side;
      stamp.rotate(rotation, new paper.Point(0, 0));
      stamp.translate(pos);
      
      // Ensure the stamp is open and remove the base segment for splicing
      stamp.closed = false;
      
      // Determine which end of the stamp is closer to our current position
      const d1 = stamp.firstSegment.point.getDistance(newPath.lastSegment.point);
      const d2 = stamp.lastSegment.point.getDistance(newPath.lastSegment.point);
      
      if (d2 < d1) {
        stamp.reverse();
      }
      
      // Now stamp is oriented correctly: firstSegment is entry, lastSegment is exit
      // We want to add all segments of the stamp to our edge path
      // IMPORTANT: We use addSegments to preserve all handles and curve information.
      // We clone the segments to avoid modifying the original stamp.
      const segmentsToAdd = stamp.segments.map(s => s.clone());
      newPath.addSegments(segmentsToAdd);
      
      stamp.remove();
    });
    
    // Add the final segment to the end of the edge
    newPath.add(v2);
    
    if (reversed) newPath.reverse();
    return newPath;
  }
}
